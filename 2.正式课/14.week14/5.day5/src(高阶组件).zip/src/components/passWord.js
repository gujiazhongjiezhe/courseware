import React,{Component} from 'react';
import common from './common';
class PassWord extends Component {
  render() {
    return (
      <div>
        <input value={this.props.pass} onChange={()=>{}}/>
      </div>
    );
  }
}

export default common('pass')(PassWord);
// 当前页面导出的是common高阶函数的最终的返回值，人家最终返回的是一个组件，你把当前页面的页面给人家传递进去，然后在人家组件的内部进行展示