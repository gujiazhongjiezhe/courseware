import React,{Component} from 'react';
import common from './common';
class UserName extends Component {
  render() {
    return (
      <div>
        <input value={this.props.user} onChange={()=>{}}/>
      </div>
    );
  }
}

export default common('user')(UserName);