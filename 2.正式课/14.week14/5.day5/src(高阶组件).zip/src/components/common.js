import React, { Component } from 'react';

let common = (type) => (Children) => {
  // children是userName一个组件
  return class Common extends Component {
    constructor(props) {
      super(props);
      this.state = {
        [type]: ''
      };
    }
    componentDidMount() {

      this.setState({
        [type]: localStorage.getItem(type)
      })
    }
    render() {
      return <div>
      1111
        <Children {...this.state}></Children>
      </div>
       
      
    }
  }
}

export default common;

// export default common()(UserName);
// common高阶函数执行最终会返回一个高阶组件，然后当高阶函数执行的时候你把当前页面的组件以实参的形式给他传递到了common内部，然后在高阶组件里边进行展示
