import React from 'react';
import ReactDOM from 'react-dom';
import UserName from './components/userName';
import PassWord from './components/passWord'
ReactDOM.render(<div>
  <UserName></UserName>
  <PassWord></PassWord>
</div>,document.getElementById('root'));
// 高阶组件