<template>
  <div id="app">
    <vote></vote>
  </div>
</template>

<script>
import vote from "./components/vote";
export default {
  name: "App",
  components: {
    vote
  },
};
</script>

<style lang="less">
#app {
}
</style>
