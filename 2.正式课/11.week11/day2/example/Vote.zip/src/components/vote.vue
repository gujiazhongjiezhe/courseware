<style lang="less">
    .vote {
      border:2px solid black;
      padding:10px;
      width: 400px;
      margin: 20px auto;
    }
</style>
<template>
  <div class="vote">
    <vote-header></vote-header>
    <vote-content></vote-content>
    <vote-footer></vote-footer>
  </div>
</template>
<script>
import voteHeader from './vote-header';
import voteContent from './vote-content';
import voteFooter from './vote-footer';
export default {
    components:{
      voteHeader,
      voteContent,
      voteFooter
    }
}
</script>

