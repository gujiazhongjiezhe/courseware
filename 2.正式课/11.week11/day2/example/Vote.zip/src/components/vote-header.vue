<style lang="less">
  .header {
    font-size:20px;
    color:red;
    font-weight: 700;
  }
</style>
<template>
  <div class="header">
    {{title}} 总人数:{{total}}
  </div>
</template>
<script>
export default {
    data(){
      return {
        title:this.$store.state.title
      }
    },
    computed:{
      total(){
        return this.$store.state.supNum + this.$store.state.popNum
      }
    }
}
</script>

