<style lang="less">
  .footer {
    border-top:5px solid gainsboro;
    button {
      margin-right:5px;
      margin-top:10px;
      background:red;
    }
  }
</style>
<template>
  <div class="footer">
    <button class="button" @click="sup">支持</button>
    <button @click="popAction">反对</button>
  </div>
</template>
<script>
import {mapMutations,mapActions} from 'vuex';
export default {
  methods:{
    ...mapActions(['popAction']),
    ...mapMutations(['sup'])
  }
}
</script>

