<style lang="less">
  
</style>
<template>
  <div>
    <p>支持人数：<span>{{supNum}}</span></p>
    <p>反对人数：<span>{{popNum}}</span></p>
    <p>支持率：<span>{{rate}}</span></p>
  </div>
</template>
<script>
import {mapState,mapGetters} from 'vuex';
export default {
  computed:{
    ...mapState(['supNum','popNum']),
    // ...mapState({
    //   // 形参state就是store中的state对象
    //   supNum:(state)=>{
    //       return state.supNum
    //   },
    //   popNum:(state)=>{
    //       return state.popNum
    //   },
    //   num:(state)=>{
    //     return state.obj.num
    //   }
    // }),
     ...mapGetters(['rate'])
  }
}
</script>

