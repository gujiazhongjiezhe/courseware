<template>
  <div >
    <p class="content">
      我是组件二
      </p>
  </div>
</template>

<script>
export default {
    name:'com-second',
    data(){
      return {
      
      }
    }
}
</script>
<style lang="less">
  .content {
    color:red
  }
</style>
  
