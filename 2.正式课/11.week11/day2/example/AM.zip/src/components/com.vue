<template>
  <div >
    <p class="content" @click="add">
      我是组件一{{num}}
      </p>
  </div>
</template>

<script>
import {createNamespacedHelpers} from 'vuex';
let {mapState,mapMutations} = createNamespacedHelpers('com1');
// createNamespacedHelpers这是vuex对象中的一个属性，当这个属性执行的时候，会返回一个对象，对象里的遍历器生成的是当前组件对应的store里的东西
export default {
    name:'com',
    data(){
      return {
        
      }
    },
    methods:{
      // fn(){
      //   this.$store.commit('com1/add')
      // }
      ...mapMutations(['add'])
   
    },
    created(){
      console.log(this);
    },
    computed:{
      ...mapState(['num']),

    }
}
</script>
<style lang="less">
  .content {
    color:red
  }
</style>
  
