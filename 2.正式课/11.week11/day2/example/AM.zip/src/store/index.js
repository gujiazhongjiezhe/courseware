import Vue from 'vue';
import Vuex from 'vuex';
import com1 from './com';
import com2 from './com-second';

// 因为Vuex是Vue的一个插件，所以在使用vues之前要注册一下
Vue.use(Vuex);



export default new Vuex.Store({
  modules:{
    com1,
    com2
  },
  state:{
    num:1,
    public:{
      a:0,
      b:1
    }
  },
  getters:{

  },
  mutations:{

  },
  actions:{

  }
});
// let store = new Vuex.Store({

// })

