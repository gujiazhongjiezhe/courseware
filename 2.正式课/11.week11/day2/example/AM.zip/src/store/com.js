export default {
  namespaced:true,
  state:{
    num:100
  },
  mutations:{
    add(state){
      state.num++
    }
  },
  actions:{

  }
}