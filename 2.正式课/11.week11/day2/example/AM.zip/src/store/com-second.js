export default {
  namespaced:true,
  state:{
    num:200
  },
  mutations:{
    add(state){
      state.num++
    }
  },
  actions:{
    
  }
}