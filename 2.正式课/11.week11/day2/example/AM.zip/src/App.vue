<template>
  <div id="app">
    1223434455
    <com></com>
    <comSecond></comSecond>
    <!-- 4.使用组件 -->
  </div>
</template>

<script>
import com from './components/com'; // 2.引入组件
import comSecond from './components/com-second';

// 组件的使用
// 创建组件-->引入组件-->注册组件-->使用组件
export default {
  name: 'App',
  components: {
   com, // 3.注册组件
  comSecond
  }
}
</script>

<style lang="less">
#app {

}
</style>
