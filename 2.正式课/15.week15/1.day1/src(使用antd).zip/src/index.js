import React,{Component} from 'react';
import ReactDOM from 'react-dom';
// import 'antd/dist/antd.css'; // 引入antd的样式
import App from './App'


ReactDOM.render(<App></App>, document.getElementById('root'));