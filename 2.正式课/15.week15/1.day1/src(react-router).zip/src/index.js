import React from 'react';
import ReactDOM from 'react-dom';
import { HashRouter, Route, Switch, Link } from 'react-router-dom';
import App from './App'

let Home = () => { return <div>home</div> };
let Detail = () => { return <div>detail</div> };
let List = () => { return <div>list</div> };
let NoFound = () => { return <div>NoFound</div> }
ReactDOM.render(<App>
    <Switch>
      <Route path="/" exact={true} component={Home}></Route>
      <Route path="/detail" exact={true} component={Detail}></Route>
      <Route path="/detail/info" component={List}></Route>
      <Route component={NoFound}></Route>
    </Switch>
 
</App>, document.getElementById('root'));