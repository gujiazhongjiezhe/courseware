import React, { Component } from 'react';
import { HashRouter, Route, Switch, Link } from 'react-router-dom';
import './App.css';
// 当前组件时项目的根组件



class App extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    // 当前的操作就相当于vueRouter中的路由映射表 '/detail/info'
    // 在react中，路由时模糊匹配，当匹配成功时，还会继续向下进行匹配
    // 在Route组件的行间写上exact，会让组件的path进行精确匹配
    // Switch组件会让path得到匹配之后，就立即渲染组件，不会再继续向下进行匹配了

    return (
      <HashRouter>
        <Link to={'/detail'}>点击</Link>

        <div>
          {/* 这块就是显示路由组件的地方，相当于vue中的vue-router中的router-view */}
          {/* {this.props.children} */}
          {/* <Switch>
            <Route path="/" exact={true} component={Home}></Route>
            <Route path="/detail" exact={true} component={Detail}></Route>
            <Route path="/detail/info" component={List}></Route>
            <Route component={NoFound}></Route>
          </Switch> */}
        </div>

      </HashRouter>

    );
  }
}

export default App;